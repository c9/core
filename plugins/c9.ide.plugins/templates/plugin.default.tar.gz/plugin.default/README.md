# c9.ide.example

This is the Cloud9 default plugin example