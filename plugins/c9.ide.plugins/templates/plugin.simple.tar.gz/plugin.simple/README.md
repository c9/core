# c9.ide.simple

This is the Cloud9 simple plugin example